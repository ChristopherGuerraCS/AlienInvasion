import pygame
import random
from pygame.sprite import Sprite

class BonusAlien(Sprite):
    """A class to represent the bonus alien (UFO) that moves across the screen."""

    def __init__(self, ai_game):
        """Initialize the bonus alien with a random movement direction."""
        super().__init__()
        self.screen = ai_game.screen
        self.settings = ai_game.settings
        self.game = ai_game

        self.fixed_spawn_height = 50  # Set fixed height for spawn

        # Load the bonus alien image
        self.image = pygame.image.load(f"images/alien00.png")  # Adjust image path if needed
        self.rect = self.image.get_rect()
        self.rect.y = self.fixed_spawn_height  # Position it near the top of the screen

        # Random horizontal spawn position (left or right side of the screen)
        if random.choice([True, False]):
            self.rect.x = self.settings.scr_width
            self.direction = -1  # Move left
        else:
            self.rect.x = -self.rect.width
            self.direction = 1  # Move right

        self.speed = 3  # UFO speed

        # Initialize spawn delay (10 seconds after the game starts)
        self.last_spawn_time = pygame.time.get_ticks()
        self.spawn_time = self.last_spawn_time + 6000  # Set the spawn time to 10 seconds after the game starts

    def update(self):
        """Move the UFO horizontally across the screen."""
        if pygame.time.get_ticks() >= self.spawn_time:
            self.rect.x += self.speed * self.direction

            # If the UFO goes off-screen, remove it and reset the spawn timer
            if self.rect.right < 0 or self.rect.left > self.settings.scr_width:
                self.kill()  # Remove the UFO once it leaves the screen
                self.game.ufo_spawned = False  # Reset to None to allow a new UFO to spawn
                self.game.bonus_alien = None
                self.reset_spawn_time()  # Reset the spawn time for the next UFO
                print("UFO left the screen, set to None")
        else:
            pass  # Don't update position if it hasn't been 10 seconds yet

    def reset_spawn_time(self):
        """Reset the spawn time after the UFO leaves the screen."""
        self.spawn_time = pygame.time.get_ticks() + 6000  # Add 6 seconds cooldown after UFO leaves
        self.last_spawn_time = pygame.time.get_ticks()  # Update the last spawn time

    def check_collision(self):
        """Check for collision between lasers and the UFO."""
        if pygame.sprite.spritecollideany(self, self.game.ship.lasers):
            self.game.bonus_alien = None  # Reset UFO once it is hit
            self.kill()  # Remove the UFO
            self.game.stats.score += 500  # Increase score for hitting the UFO
            self.game.sb.prep_score()  # Update the scoreboard
            # self.game.sound.play_explosion()  # Uncomment when sound is added