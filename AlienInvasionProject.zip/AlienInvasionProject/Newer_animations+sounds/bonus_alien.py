import pygame as pg
import random
from pygame.sprite import Sprite
from timer import Timer
from sound import Sound

class BonusAlien(Sprite):
    """A class to represent the bonus alien (UFO) that moves across the screen."""

    def __init__(self, ai_game):
        """Initialize the bonus alien with a random movement direction."""
        super().__init__()
        self.screen = ai_game.screen
        self.settings = ai_game.settings
        self.game = ai_game

        self.fixed_spawn_height = 50  # Set fixed height for spawn

        # Load the bonus alien image (change path if needed)
        self.image = pg.image.load("images/ufo.png")
        self.rect = self.image.get_rect()
        self.rect.y = self.fixed_spawn_height  # Position it near the top of the screen

        # Random horizontal spawn position (left or right side of the screen)
        self.direction = random.choice([-1, 1])  # Randomly choose to go left or right
        self.reset_position()

        self.speed = 3  # UFO speed
        self.spawn_delay = random.randint(10000, 30000)  # Random delay for UFO reappearance
        self.last_spawn_time = pg.time.get_ticks()  # Track time since last spawn

        self.explosion_images = [pg.image.load(f"images/a_explosion{n}.png") for n in range(4)]  # Explosion frames
        self.explosion_timer = Timer(images=self.explosion_images, start_index=0, loop_continuously=False, delta=100)

        # Regular animation (UFO sprite)
        self.timer = Timer(images=[self.image], start_index=0, delta=500)  # Regular UFO image

        self.dead = False
        #self.sound = Sound()

    def reset_position(self):
        """Reset the UFO to the starting position on the correct side."""
        if self.direction == -1:
            # Start on the right side, moving left
            self.rect.x = self.settings.scr_width
        else:
            # Start on the left side, moving right
            self.rect.x = -self.rect.width

    def update(self):
        if not self.dead:
            self.rect.x += self.speed * self.direction

        # If the UFO goes off-screen, wait for a respawn time
        if self.rect.right < 0 or self.rect.left > self.settings.scr_width:
            current_time = pg.time.get_ticks()
            # Wait for the spawn delay before resetting the UFO's position
            if current_time - self.last_spawn_time >= self.spawn_delay:
                self.direction = random.choice([-1, 1])  # Randomly choose direction again
                self.reset_position()  # Reset its position for next spawn
                self.last_spawn_time = current_time  # Update the time
        if self.dead:
            self.image = self.explosion_timer.current_image()
        else:
            self.image = self.timer.current_image()

        if self.explosion_timer.finished() and self.dead:
            self.reset_position()
            self.dead = False
            self.last_spawn_time = pg.time.get_ticks()
        self.screen.blit(self.image, self.rect)

    def check_collision(self):
        """Check for collision between lasers and the UFO."""
        if pg.sprite.spritecollideany(self, self.game.ship.lasers):
            self.hit()
            self.kill()  
            self.game.bonus_alien = None  # Reset UFO
            self.game.bonus_alien_spawned = False  # Allow the bonus alien to respawn
            self.game.stats.score += 500  # Increase score for hitting the UFO
            self.game.sb.prep_score()  # Update the scoreboard
            print("UFO hit by laser, not respawning")

        if pg.sprite.collide_rect(self, self.game.ship):
            self.kill()  # Remove the UFO when it collides with the ship
           # self.game.bonus_alien = None  # Reset UFO
           # self.game.bonus_alien_spawned = False  # Allow the bonus alien to respawn
            self.game.ship.ship_hit()  # Trigger ship's hit function (e.g., lose life)
            print("UFO collided with the ship, triggering ship hit")
    
    def hit(self):
        self.dead = True
        self.timer = self.explosion_timer
        self.game.sound.play_ufo_sound()

    def spawn_bonus_alien(self):
        if self.bonus_alien is None:
            self.bonus_alien = BonusAlien(self)
            self.bonus_alien.add(self.bonus_alien)